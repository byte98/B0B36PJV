package cz.cvut.fel.pjv;

public class BruteForceAttacker extends Thief {
    
    /**
     * Stores array of character used in password
     */
    private char[] characters;
    
    /**
     * Size of password
     */
    private int size;
    
    @Override
    public void breakPassword(int sizeOfPassword) {
        // write your code 
        this.characters = super.getCharacters();
        this.size = sizeOfPassword;
        
        //Get first allowed password
        char[] first = new char[this.size];
        for (int i = 0; i < this.size; i++)
        {
            first[i] = this.characters[0];
        }
        
        //Get last allowed password
        char[] last = new char[this.size];
        for (int i = 0; i < this.size; i++)
        {
            last[i] = this.characters[this.characters.length - 1];
        }
        
        this.tryPassword(first, last);
    }
    /**
     * Recursive function to try password
     * @param password Password to check
     * @param lastAllowed Last password allowed to check
     * @return <code>TRUE</code> if password has been revealed, <code>FALSE</code> if not.
     */
    private boolean tryPassword(char[] password, char[] lastAllowed)
    {
        boolean reti = false;
        if (super.tryOpen(password) == false)
        {
            if (password != lastAllowed)
            {
                reti = this.tryPassword(this.getNextPassword(password), lastAllowed);
            }
        }
        else
        {
            reti = true;
        }
        return reti;
    }
    
    /**
     * Function to generate next password
     * @param password Password to generate successor of
     * @return Next password
     */
    private char[] getNextPassword(char[] password)
    {
        char[] reti = new char[password.length];
        String allowedChars = new String(this.characters);
        int overflow = 0;
        for (int i = reti.length - 1; i >= 0 ; i--)
        {
            int idx = allowedChars.indexOf(password[i]);
            idx++;
            idx += overflow;
            overflow = 0;
            if (idx >= this.characters.length)
            {
                idx = idx % this.characters.length;
                overflow = 1;
            }
            reti[i] = this.characters[idx];
        }
        return reti;
    }
    
}
